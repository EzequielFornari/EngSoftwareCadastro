
package meuprojeto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;


public class Meuprojeto {
  private Connection con;
  private PreparedStatement stmt;
  
  public void conectar(){
       String username = "postgres";
       String password = "123456";
       String url = "jdbc:postgresql://localhost/CRUD";
        try {
            Class.forName("org.postgresql.Driver");

            con = DriverManager.getConnection(url, username, password);
        }catch(Exception e){
            System.out.println("Falha na Conexao "+ e.getMessage());
        }
  }    
  public void cadastraDados(String placa, String nome, String preco,String ano,String modelo){  
      try{
       Statement stmt = con.createStatement(); 
       stmt.execute("INSERT INTO automovel (placa,nome,preco,ano,modelo) VALUES('"+placa+"',' "+nome+"','"+preco+"','"+ano+"','"+modelo+"')");
       JOptionPane.showMessageDialog(null,"Dados inseridos com Sucesso");
      }catch(Exception e){
          System.out.println("Falha conexão na Inserção"+e.getMessage());
      } 
  }

  public ResultSet BuscaDados(String sql){
      ResultSet rs = null;
      try{
       Statement stmt = con.createStatement(); 
       rs = stmt.executeQuery(sql);
       JOptionPane.showMessageDialog(null,"Dados Buscados com Sucesso");
      }catch(Exception e){
         System.out.println("Erro no SQl "+e.getMessage());
      }
      return rs;
  }
  
  public void desconectar(){
      try{
          con.close();
      }catch(SQLException e){
         System.out.println("Erro ao desconectar "+e.getMessage());
      }
  }
  
  
}
